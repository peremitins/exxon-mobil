<template>
  <div class="footer">
    <p class="footer__text">
      Данные на странице носят конфиденциальный характер и принадлежат компании ExxonMobil.
    </p>
    <p class="footer__text">
      Не создавайте принтскрин и не осуществляйте перенос или копирование данных во внешние источники.
    </p>
  </div>
</template>

<script>
export default {
  name: 'Footer'
}
</script>