module.exports = {
  publicPath: '/exxon-mobil/'
}